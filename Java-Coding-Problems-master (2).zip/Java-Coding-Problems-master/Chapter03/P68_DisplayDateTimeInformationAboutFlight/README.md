# Display date-time information about a flight
Write a program that displays information about a scheduled flight time of 15 hours and 30 minutes. More exactly, a flight from Australia, Perth to Europe, Bucharest.
