# Start and end of a day
Write a program that returns the start and end of a day.
