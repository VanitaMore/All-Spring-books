# Transform strings
Write several snippets of code for transforming a string in another string.