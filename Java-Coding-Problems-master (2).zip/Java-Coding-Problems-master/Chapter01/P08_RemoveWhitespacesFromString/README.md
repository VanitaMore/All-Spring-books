# Remove whitespaces from string
Write a program that removes all whitespaces from the given string.