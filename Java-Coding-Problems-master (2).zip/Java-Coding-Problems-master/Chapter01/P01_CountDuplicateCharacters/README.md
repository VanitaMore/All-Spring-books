# Count duplicate characters
Write a program that counts duplicate characters from a given string.