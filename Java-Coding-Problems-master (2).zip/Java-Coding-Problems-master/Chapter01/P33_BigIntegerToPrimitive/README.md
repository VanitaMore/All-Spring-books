# BigInteger to a primitive type
Write a program that extracts the primitive type value from the given **BigInteger**.