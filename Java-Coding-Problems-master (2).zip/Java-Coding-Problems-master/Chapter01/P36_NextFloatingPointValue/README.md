# Next floating-point value
Write a program that returns the next floating-point adjacent to the given **float**/**double** in the direction of positive/negative infinity.