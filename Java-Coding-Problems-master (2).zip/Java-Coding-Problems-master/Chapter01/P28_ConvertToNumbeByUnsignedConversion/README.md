# Convert to a number by an unsigned conversion
Write a program that converts the given **int** to a **long** by an unsigned conversion.