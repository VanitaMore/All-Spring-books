# Multiply two large int/long and operation overflow
Write a program that multiplies two large **int**/**long** and throws an **ArithmeticException** in case of operation overflow.