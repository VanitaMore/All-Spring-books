# Compact Number Formatting
Write a program that format the number 1000000 to 1M (US locale) and to 1 Mln (Italian locale). In addition, parser 1M and 1 Mln from **String** to **Number**.