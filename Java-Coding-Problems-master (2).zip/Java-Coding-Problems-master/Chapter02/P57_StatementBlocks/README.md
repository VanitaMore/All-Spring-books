# Statement blocks
Write a snippet of code for exemplifying the JDK 12 **switch** with **case** labels that point to a curly-braced block. 
