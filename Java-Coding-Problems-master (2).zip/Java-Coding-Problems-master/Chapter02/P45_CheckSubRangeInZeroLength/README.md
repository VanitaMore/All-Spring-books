# Checking sub-range in the range from 0 to length
Write a program that checks if the given sub-range [given start, given end) is within the bounds of the range from [0, given length). If the given sub-range is not in the [0, given length) range then throw an **IndexOutOfBoundsException**.
