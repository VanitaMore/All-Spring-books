# Checking null references in functional-style and non-functional code 
Write a program that performs **null** checks on the given references in a functional-style and non-functional code.
