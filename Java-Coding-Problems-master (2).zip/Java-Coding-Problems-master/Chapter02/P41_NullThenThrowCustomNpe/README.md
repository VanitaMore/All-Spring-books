# Checking null references and throw customized NullPointerException
Write a program that performs **null** checks on the given references and throw **NullPointerException** with custom messages.
