# Writing an immutable class via the Builder pattern
Write a program that represents an implementation of the Builder pattern in an immutable class.