# Cloning objects
Write a program that exemplify shallow and deep cloning techniques.