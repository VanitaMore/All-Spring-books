# Walking paths
Write a program that visits all files within a directory including subdirectories. Moreover, write a program that searches a file by name, deletes a directory, moves a directory and copies a directory.
