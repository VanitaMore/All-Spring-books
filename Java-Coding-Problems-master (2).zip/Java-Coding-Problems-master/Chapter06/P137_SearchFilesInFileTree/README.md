# Searching for files/folders in a file tree
Write a program that searches for the given files/folders in the given file tree.
