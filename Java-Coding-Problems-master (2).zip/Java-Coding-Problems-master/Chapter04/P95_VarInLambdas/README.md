# LVTI and lambdas
Explain by examples how LVTI can be used in combination with lambda expressions.
