# LVTI and variables scope
Explain and exemplify why LVTI should minimize the variables scope as much as possible.
