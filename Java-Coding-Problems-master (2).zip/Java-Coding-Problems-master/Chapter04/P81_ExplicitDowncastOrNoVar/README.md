# Explicit downcast or better avoid var
Write a program that exemplifies the combination of **var** and explicit downcast. Explain why **var** should be avoided.
