# LVTI and for loops
Write several examples that exemplifies the usage of LVTI in **for** loops.
