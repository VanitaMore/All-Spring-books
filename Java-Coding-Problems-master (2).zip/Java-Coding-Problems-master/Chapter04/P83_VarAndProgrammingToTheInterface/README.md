# Combining LVTI and programming to the interface technique
Write a program that exemplify the usage of **var** via *programming to the interface* technique.
