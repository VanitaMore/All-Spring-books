# Using LVTI to break up nested/large chains of expressions
Write a program that exemplifies the usage of LVTI for breaking up a nested/large expression.
