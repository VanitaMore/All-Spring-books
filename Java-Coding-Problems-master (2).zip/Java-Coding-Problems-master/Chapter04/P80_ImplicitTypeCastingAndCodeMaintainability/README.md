# Using var and implicit type casting to sustain the code maintainability
Write a program that exemplifies how **var** and Implicit Type Casting can sustain the code maintainability.
