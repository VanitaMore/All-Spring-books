# Using var with primitive types
Write a program that exemplifies the usage of **var** with Java primitive types (**int**, **long**, **float** and **double**).
