package modern.challenge;

public class Report {    
}
