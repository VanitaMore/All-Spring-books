# Sorting an array
Write several programs that exemplifies different sorting algorithms for arrays. Supplementary, write a program for shuffling arrays.
