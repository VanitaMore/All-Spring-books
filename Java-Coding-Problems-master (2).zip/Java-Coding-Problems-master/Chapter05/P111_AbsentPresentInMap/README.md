# Computing if absent/present in a Map
Write a program that computes the value of an absent key or a new value of a present key.
